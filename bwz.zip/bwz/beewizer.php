<?php
/*
 *	Plugin Name: BeeWizer Nieuws overzicht
 *	Plugin URI: zwf-ontwerp.nl
 *	Description: Importeer berichten vanuit het portaal
 *	Version: 1.0
 *	Author: Matthijs Glashouwer
 *	Author URI: matthijs@zwf-ontwerp.nl
 *	License: GPL2
 *
*/

$plugin_url = WP_PLUGIN_URL . '/beewizer';



function bwznews_articles_menu(){

	add_options_page(
		'BeeWizer News Overzicht plugin',
		'BeeWizer',
		'manage_options',
		'beewizer',
		'bwznews_articles_options_page'
	);

}

add_action('admin_menu', 'bwznews_articles_menu');
add_action( 'wp_enqueue_scripts', 'ajax_test_enqueue_scripts' );

function ajax_test_enqueue_scripts() {
	wp_enqueue_script( 'test', plugins_url( '/inc/test.js', __FILE__ ), array('jquery'), '1.0', true );
}


function bwznews_articles_options_page() {

	if (!current_user_can('manage_options' )){
		wp_die('Niet genoeg rechten om deze pagina te bekijken');
	}
	$bwznews_results = bwznews_articles_get_results();
	global $plugin_url;
	
	require('inc/options-page-wrapper.php');

}


function bwznews_articles_get_results(){
			
		$json_feed_url = 'http://cvo.education.misp.nl/republish';

		$json_feed = wp_remote_get($json_feed_url);

		if( is_wp_error( $json_feed)) {
			return false;
		}

		$bwznews_results = json_decode($json_feed['body'],TRUE);

		return $bwznews_results;
		
}


?>